    /**
     * @return a list of all the types
     */
    public static Vector getTypes() {
        if (types == null) {
            types = new Vector();
            types.addElement(new KnowledgeTypeNode(Critic.KT_DESIGNERS));
            types.addElement(new KnowledgeTypeNode(Critic.KT_CORRECTNESS));
            types.addElement(new KnowledgeTypeNode(Critic.KT_COMPLETENESS));
            types.addElement(new KnowledgeTypeNode(Critic.KT_CONSISTENCY));
            types.addElement(new KnowledgeTypeNode(Critic.KT_SYNTAX));
            types.addElement(new KnowledgeTypeNode(Critic.KT_SEMANTICS));
            types.addElement(new KnowledgeTypeNode(Critic.KT_OPTIMIZATION));
            types.addElement(new KnowledgeTypeNode(Critic.KT_PRESENTATION));
            types.addElement(new KnowledgeTypeNode(Critic.KT_ORGANIZATIONAL));
            types.addElement(new KnowledgeTypeNode(Critic.KT_EXPERIENCIAL));
            types.addElement(new KnowledgeTypeNode(Critic.KT_TOOL));
        }
        return types;
    }